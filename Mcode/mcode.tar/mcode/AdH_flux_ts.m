function whiteditch_flux_script(basename)
% clear

 basename='June14-hot2'
t0='01/01/2008 00:00:00';
units =1;


%% plots the data as a timeseries and saves
data1=read_tflx_discharges(basename,t0,units);

fid=fopen([basename '_tflx_ts'],'w')
%n=length(string_name)
%t=length(data1.fluxes)
% fprintf(fid,'Time Discharge n%s\n',string_name{i},i=1:n);
%for i=1:t
%  csvwrite(fid,data1.time(i),data1.fluxes(i,:));
%end

location{1}='Bohemia U/S';
location{2}='Bohemia D/S';
location{3}='Baptiste Collette';
location{4}='Grand Pass';
location{5}='West Bay';
location{6}='Cubits Gap';
location{7}='Southwest Pass';
location{8}='South Pass';
location{9}='Pass A Loutre';


formatSpec='%20f';
fprintf(fid,'%20s','Time');
for i=1:length(data1.fluxes(1,:))
    fprintf(fid,'%20s',location{i});
    formatSpec=[formatSpec ' %20f'];
end
fprintf(fid,'\n');
formatSpec=[formatSpec '\n'];

temp=data1.time;
for i=1:length(data1.fluxes(1,:))
    temp(i+1,:)=data1.fluxes(:,i);
end

fprintf(fid,formatSpec,temp);


